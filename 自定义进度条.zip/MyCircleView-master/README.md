# MyCircleView
圆形彩色进度条
![img](https://github.com/AracyGit/MyCircleView/blob/master/MyCircleView/MyCircleView/CircleView.gif?raw=true)
